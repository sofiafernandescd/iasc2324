'''
 # @ Author: Sofia Condesso - 50308
 # @ Description:
 '''

from typing import Dict, List
from modelo_mundo import ModeloMundo2D, Estado
from accao import Accao


class FrenteOnda():
    
    def __init__(self, gama: float, valor_max: float) -> None:
        """Inicializa o algoritmo Frente-de-Onda.
        :param gama: factor de desconto
        :param valor_max: valor máximo
        """
        self.gama = gama
        self.valor_max = valor_max
        self.V = {} # # Dicionário para armazenar valores associados a estados
        self.frente_onda = []

    def propagar_valor(self, modelo, objectivos) -> Dict[Estado, float]:
        """Propagação de valor através do algoritmo Frente de Onda.
        :param modelo: modelo
        :param objectivos: objectivos
        """
        for s in objectivos:
            self.V[s] = self.valor_max  # valor máximo para objectivos
            self.frente_onda.append(s)

        while self.frente_onda:
            s = self.frente_onda.pop(0)
            for sn in self.__adjacentes(modelo, s):
                # self.V[s] += self.gama * modelo.T(s, sn) * self.V[sn]
                #v = self.V[sn]*pow(self.gama, modelo.distancia(s, sn))
                # v = self.V.get(sn, '-inf') * pow(self.gama, modelo.distancia(s, sn))
                v = self.V[s] * pow(self.gama, modelo.distancia(s, sn))
                if v > self.V.get(sn, float('-inf')):
                    self.V[sn] = v
                    self.frente_onda.append(sn)


    def __adjacentes(self, modelo, estado) -> List[Estado]:
        """Obter estados adjacentes.
        :param modelo: modelo
        :param estado: estado
        :return: estados adjacentes
        """
        estados_adjacentes = []
        for accao in modelo.A:
            estado_suc = modelo.T(estado, accao)
            if estado_suc:
                estados_adjacentes.append(estado_suc)
        return estados_adjacentes
        


class PlanFrenteOnda():

    def __init__(self, modelo: ModeloMundo2D, gama: float = 0.98, valor_max: float = 1) -> None:
        """Inicializa o planeador.
        :param modelo: modelo do mundo
        """
        self.__modelo = modelo
        self.__frente_onda = FrenteOnda(gama, valor_max)

    def V(self) -> Dict[Estado, float]:
        """Função de valor.
        :return: valores
        """
        return self.__frente_onda.V

    def planear(self, objectivos: List[Estado]) -> Dict[Estado, Accao]:
        """Planear.
        :param objectivos: objectivos
        :return: plano
        """
        self.__V = self.__frente_onda.propagar_valor(self.__modelo, objectivos)
        politica = {
            estado: max(self.__modelo.A, key=lambda accao: self.__valor_accao(estado, accao)) 
            for estado in self.__modelo.S 
            if estado not in objectivos
        }
        return politica

    def __valor_accao(self, estado: Estado, accao: Accao) -> float:
        """Obter valor de uma acção.
        :param estado: estado
        :param accao: acção
        :return: valor
        """
        novo_estado = self.__modelo.T(estado, accao)
        return self.V().get(novo_estado, float('-inf'))
        
