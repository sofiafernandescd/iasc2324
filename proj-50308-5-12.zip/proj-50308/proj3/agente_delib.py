'''
 # @ Author: Sofia Condesso
 # @ Description:
 '''

from abc import ABC
from typing import List


class AgenteDelib(ABC):
    def __init__(self) -> None:
        pass

    def executar(self) -> None:
        """Implementa o processwo de tomada de decisão do agente deliberativo"""
        pass

    def _percepcionar(self) -> Percepcao:
        pass

    def _atualizar_crenças(self, percepcao: Percepcao) -> None:
        pass

    def _deliberar(self) -> List[Estado]:
        pass

    def _planear(self, objectivos: List[Estados]) -> Plano:
        pass

    def _executar_plano(plano: Plano) ->  None:
        pass

        

class AgenteFrenteOnda(AgenteDelib):
    def __init__(self, num_ambiente: int) -> None:
        super.__init__()
        self.num_ambiente = num_ambiente
        self.__modelo_mundo = ModeloMundo2D()
        self.__planeador = PlanFrenteOnda()
        self.__visualizador = VisValorPol()

    
    def _percepcionar(self) -> Percepcao:
        
        pass

    def _actualizar_crencas(self, percepcao: Percepcao) -> None:


        pass

    def _deliberar(self) -> List[Estado]:
        pass

    def _planear(self, objectivos: List[Estados]) -> Plano:
        pass

    def _executar_plano(plano: Plano) ->  None:
        pass
        

class VisValorPol():

    def __init__(self) -> None:
        pass

    def mostrar(sel, x_max: int, y_max: int, V: Dict[Estado, float], politica: Dict[Estado, Accao]) -> None:
        pass