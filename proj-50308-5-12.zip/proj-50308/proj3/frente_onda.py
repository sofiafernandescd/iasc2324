'''
 # @ Author: Sofia Condesso - 50308
 # @ Description:
 '''



class FrenteOnda():
    
    def __init__(self, gama: float, valor_max: float) -> None:
        """Inicializa o algoritmo Frente-de-Onda.
        :param gama: factor de desconto
        :param valor_max: valor máximo
        """
        self.gama = gama
        self.valor_max = valor_max
        self.V = {} # # Dicionário para armazenar valores associados a estados
        self.frente_onda = []

    def propagar_valor(self, modelo, objectivos) -> Dict[Estado, float]:
        """Propagação de valor através do algoritmo Frente de Onda.
        :param modelo: modelo
        :param objectivos: objectivos
        """
        for s in objectivos:
            self.V[s] = self.valor_max  # valor máximo para objectivos
            self.frente_onda.append(s)

        while self.frente_onda:
            s = self.frente_onda.pop(0)
            for sn in self.__adjacentes(modelo, s):
                #self.V[s] += self.gama * modelo.T(s, sn) * self.V[sn]
                v = self.V[sn]*pow(self.gama, modelo.distância(s, sn))
                if v > self.V.get(sn, float('-inf')):
                    self.V[sn] = v
                    self.frente_onda.append(sn)


    def __adjacentes(self, modelo, estado) -> List[Estado]:
        """Obter estados adjacentes.
        :param modelo: modelo
        :param estado: estado
        :return: estados adjacentes
        """
        pass


class PlanFrenteOnda():

    def __init__(self, modelo: ModeloMundo2D, gama: float = 0.98, valor_max: float = 1) -> None:
        """Inicializa o planeador.
        :param modelo: modelo do mundo
        """
        self.modelo = modelo
        self.__frente_onda = FrenteOnda(gama, valor_max)

    def V(self) -> Dict[Estado, float]:
        """Obter valores.
        :return: valores
        """
        pass

    def planear(self, objectivos: List[Estado]) -> Dict[Estado, Accao]:
        """Planear.
        :param objectivos: objectivos
        :return: plano
        """
        pass

    def __valor_accao(self, estado: Estado, accao: Accao) -> float:
        """Obter valor de uma acção.
        :param estado: estado
        :param accao: acção
        :return: valor
        """
        pass
