
class MecAprend:
    pass